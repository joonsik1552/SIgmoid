import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('world', default_value=os.path.join(
            get_package_share_directory('my_gazebo_pkg'), 'world', 'my_world.world'),
            description='Path to the Gazebo world file'),
        
        Node(
            package='gazebo_ros',
            executable='gzserver',
            name='gazebo_server',
            output='screen',
            parameters=[{'world_name': LaunchConfiguration('world')}]
        ),
        Node(
            package='gazebo_ros',
            executable='gzclient',
            name='gazebo_client',
            output='screen',
        ),
    ])

